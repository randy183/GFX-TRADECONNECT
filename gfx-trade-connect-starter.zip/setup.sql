-- GFX TRADE CONNECT: database setup (posts + access policies)
-- Run this in Supabase SQL Editor after the profiles table has already been created.
-- Safe to run more than once for the table/index/RLS setup, but policies are created only if absent.

create table if not exists public.posts (
  id uuid primary key default gen_random_uuid(),
  author_id uuid not null references auth.users(id) on delete cascade,
  body text not null check (char_length(body) between 3 and 3000),
  post_type text not null default 'journey'
    check (post_type in ('journey','education','analysis','question','journal')),
  created_at timestamptz not null default now()
);

create index if not exists posts_created_at_idx on public.posts (created_at desc);
create index if not exists posts_author_id_idx on public.posts (author_id);

alter table public.posts enable row level security;

grant select on public.posts to authenticated;
grant insert on public.posts to authenticated;

do $$
begin
  if not exists (
    select 1 from pg_policies
    where schemaname='public' and tablename='posts' and policyname='Authenticated members can read posts'
  ) then
    create policy "Authenticated members can read posts"
      on public.posts for select to authenticated using (true);
  end if;
  if not exists (
    select 1 from pg_policies
    where schemaname='public' and tablename='posts' and policyname='Members can publish as themselves'
  ) then
    create policy "Members can publish as themselves"
      on public.posts for insert to authenticated
      with check ((select auth.uid()) = author_id);
  end if;
end $$;

-- Profile policies from the earlier setup should already exist.
-- Publicly visible only to authenticated users. Anonymous visitors cannot read profiles/posts.
-- Trader verification and admin roles are intentionally NOT included in this first stage.
