# GFX TRADE CONNECT — Starter Website

This starter contains:
- `index.html` — responsive homepage, Supabase email/password sign-up and login UI, profile editing, and a community feed.
- `setup.sql` — creates the posts table and Row Level Security policies.

## Before using it
1. Open `index.html` in a code editor.
2. Find `SUPABASE_URL` and `SUPABASE_PUBLISHABLE_KEY` near the bottom.
3. Replace the two placeholder strings with your Supabase Project URL and Publishable key.
   - Project URL: `https://YOUR_PROJECT_REF.supabase.co`
   - Key: `sb_publishable_...` (or legacy `anon` key)
   - NEVER use `sb_secret_` or `service_role` in this file.
4. In Supabase SQL Editor, run `setup.sql` to create the posts table.
5. In Supabase Authentication settings, configure the site URL and allowed redirect URLs for your eventual deployed website.
6. Commit `index.html` to your GitHub repository as the root `index.html`.
7. Test sign-up and email confirmation. Supabase email confirmation behavior depends on your project settings.

## Important limitations
This is an early working starter, not a production-ready community platform. It does not yet include:
- trader verification/admin dashboard,
- WhatsApp messaging or subscription delivery,
- moderation, reporting, blocking, or post deletion,
- password reset UI,
- terms/privacy pages,
- public/anonymous feed access,
- anti-spam/rate limits or image uploads.

Do not publish the site publicly as a fully ready trading community until these are added and tested. A publishable key is expected in browser code, but security depends on correct RLS policies. Never put privileged keys in the frontend.
